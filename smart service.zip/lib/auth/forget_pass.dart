import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:lawer_app/auth/log_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ForgetPass extends StatefulWidget {
  const ForgetPass({Key? key}) : super(key: key);
  @override
  _ForgetPassState createState() => _ForgetPassState();
}
class _ForgetPassState extends State<ForgetPass> {

  TextEditingController currrentController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confrmController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  _getSharedPref() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final myKey = prefs.getString('uid');
  }

  String? validateEmail(value)  {
    RegExp regExp = RegExp(
        r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?)*$");
    if(value.isEmpty) {
      return "Email required";
    }
    if(!regExp.hasMatch(value)) {
      return "Enter a valid Email Address";
    } else {
      return null;
    }
  }


  late FirebaseAuth _auth;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Firebase.initializeApp().whenComplete(() {
      _auth = FirebaseAuth.instance;
    });
  }
  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
        body: Container(
          color: Colors.grey[800],
          child: ProgressHUD(
            child: Builder(
                builder: (context) {
                  final progress = ProgressHUD.of(context);
                  return Form(
                    autovalidateMode: AutovalidateMode.always, key: _formKey,
                    child: SingleChildScrollView(
                      child: Row(
                        children: [
                          SizedBox(width: MediaQuery.of(context).size.width*0.05,),
                          Container(
                            width: MediaQuery.of(context).size.width*0.9,
                            child: Column(
                              children: [
                                Container(
                                  height: 320,
                                  child: Image(image: AssetImage("assets/images/law.png"),),
                                ),
                                Container(
                                  margin: const EdgeInsets.all(10),
                                  width: MediaQuery.of(context).size.width,
                                  child: TextFormField(
                                    style: TextStyle(color: Colors.white),
                                    controller: emailController,
                                    validator: validateEmail,
                                    keyboardType: TextInputType.emailAddress,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      labelText: "Email",
                                      labelStyle: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10.0,
                                ),
                                Container(
                                  margin: const EdgeInsets.all(10),
                                  //height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  child: TextFormField(
                                    style: TextStyle(color: Colors.white),
                                    controller: currrentController,
                                    obscureText: true,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      labelText: "Current Password",
                                      labelStyle: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10.0,
                                ),
                                Container(
                                  margin: const EdgeInsets.all(10),
                                  //padding: EdgeInsets.all(10),
                                  width: MediaQuery.of(context).size.width,

                                  child: TextFormField(
                                    style: TextStyle(color: Colors.white),
                                    validator: (input) {
                                      if(input!.length<6) {
                                        return 'Password must be at least 6 characters';
                                      } else if(input.isEmpty) {
                                        return "Empty";
                                      }
                                    },
                                    controller: passwordController,
                                    obscureText: true,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      labelText: "New Password",
                                      labelStyle: TextStyle(color: Colors.white),
                                      //  hintText: "Description of the new classroom",
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10.0,
                                ),
                                Container(
                                  margin: const EdgeInsets.all(10),
                                  //padding: EdgeInsets.all(10),
                                  width: MediaQuery.of(context).size.width,
                                  child: TextFormField(
                                    style: TextStyle(color: Colors.white),
                                    validator: (val) {
                                      print(val);
                                      print(passwordController.text);
                                      if(val!.isEmpty) {
                                        return "Empty";
                                      }
                                      if (val != passwordController.text) {
                                        return "Password does not match";
                                      }
                                    },
                                    controller: confrmController,
                                    obscureText: true,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      labelText: "Confirm Password",
                                      labelStyle: TextStyle(color: Colors.white),
                                      //  hintText: "Description of the new classroom",
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 20.0,
                                ),
                                SizedBox(
                                  height: 50,
                                  width: 370,
                                  child: MaterialButton(
                                    shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.only(
                                          bottomRight: Radius.circular(13.0),
                                          topRight: Radius.circular(13.0),
                                          bottomLeft: Radius.circular(13.0),
                                          topLeft: Radius.circular(13.0)),
                                    ),
                                    color: Colors.yellow[800],
                                    onPressed: () async {
                                      if(_formKey.currentState!.validate())
                                      {
                                        progress!.showWithText("Logging In...");
                                        try {
                                          await FirebaseAuth.instance.signInWithEmailAndPassword(
                                            email: emailController.text,
                                            password: currrentController.text,
                                          ).then((value) async {
                                            SharedPreferences prefs = await SharedPreferences.getInstance();
                                            await prefs.setString('uid', value.user!.uid);
                                            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => login(),
                                            ),
                                            );
                                            Stream<DocumentSnapshot> getData() async* {
                                              _auth.currentUser!; yield* FirebaseFirestore.instance.collection('User Signing Details')
                                                  .doc(value.user!.uid).snapshots();
                                            }
                                          });
                                        } on FirebaseAuthException catch (e) {
                                          if (e.code == 'user-not-found') {
                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("No user found for that email."),));
                                          }
                                          else {
                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Incorrect Password"),));
                                          }
                                        }
                                        progress.dismiss();
                                      }
                                      var updatePassword = _auth.currentUser!.updatePassword(passwordController.text).then((value) {
                                        createRecord(_auth.currentUser);
                                      });
                                    },
                                    child: const SizedBox(
                                      width: 200,
                                      height: 50,
                                      child: Center(
                                        child: Text(
                                          'Change Password',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 20.0,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: MediaQuery.of(context).size.width*0.05,),
                        ],
                      ),
                    ),
                  );
                }
            ),
          ),
        ),
      );
  }

  void createRecord(User? user) async {
    await FirebaseFirestore.instance.collection("User Signing Details").doc(user!.uid)
        .update({
      'password': passwordController.text,
    });
  }

}
