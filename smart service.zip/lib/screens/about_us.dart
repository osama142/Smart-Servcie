import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class AboutUs extends StatefulWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  State<AboutUs> createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          iconTheme: IconThemeData(color: Colors.white),
          backgroundColor: Colors.grey[900],
          leading: IconButton
            (icon: Icon(Icons.arrow_back), onPressed: () { Navigator.pop(context); },),
          title: Text("About Us",style: TextStyle(
            fontSize: 20,fontWeight: FontWeight.bold,color: Colors.yellow[700],
          ),),
        ),
        body: Container(
          color: Colors.grey[900],
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 20
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Center(
                    child: Container(
                      height: 200,
                      width: 200,
                        child: Image.asset(
                            "assets/images/law.png"
                        ),
                    ),
                  ),
                  const SizedBox(height: 10,),
                   Text(
                    "Our Mission:",
                     style: GoogleFonts.playfairDisplay(
                       textStyle: TextStyle(fontSize: 25,color: Colors.yellow[700],fontWeight: FontWeight.bold,fontStyle: FontStyle.italic),
                     ),
                  ),
                  const SizedBox(height: 10,),
                  RichText(
                    textAlign: TextAlign.justify,
                    text: const TextSpan(
                        children: <TextSpan>[
                          TextSpan(
                            text: "We deliver highly skilled, effective and innovative legal consultation dedicated to excellence services by maintaining a collaborative diverse and inclusive environment.",
                            style: TextStyle(
                                fontSize: 18,fontStyle: FontStyle.italic,
                                color: Colors.white
                            ),
                          )
                        ]
                    ),
                  ),
                  const SizedBox(height: 30,),
                   Text(
                    "Our Vision:",
                     style: GoogleFonts.playfairDisplay(
                       textStyle: TextStyle(fontSize: 25,color: Colors.yellow[700],fontWeight: FontWeight.bold,fontStyle: FontStyle.italic),
                     ),
                  ),
                  const SizedBox(height: 10,),
                  RichText(
                    textAlign: TextAlign.justify,
                    text: const TextSpan(
                        children: <TextSpan>[
                          TextSpan(
                            text: "To provide Portland with a technological network of innovative legal consultation, representation, taxation service and support to quality costumer services.",
                            style: TextStyle(
                                fontSize: 18,fontStyle: FontStyle.italic,
                                color: Colors.white
                            ),
                          )
                        ]
                    ),
                  ),
                  const SizedBox(height: 40,),
                   Center(
                     child: Text(
                      "Our Team",
                      style: GoogleFonts.playfairDisplay(
                        textStyle: TextStyle(fontSize: 35,color: Colors.yellow[700],fontWeight: FontWeight.bold,fontStyle: FontStyle.italic),
                      ),
                  ),
                   ),
                  const SizedBox(height: 40,),
                  Center(
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 200,
                          width: 200,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset("assets/images/waqar.jpg"),
                          ),
                        ),
                        const SizedBox(height: 5,),
                        const Text(
                          "Waqar Azeem Khitran",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,color: Colors.white
                          ),
                        ),
                        const SizedBox(height: 5,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text("Attorney Originator",style: TextStyle(fontSize: 18,
                                fontWeight: FontWeight.bold,color: Colors.white),),
                            Text("(Smart Support)",style: TextStyle(fontSize: 15,
                                fontWeight: FontWeight.bold,color: Colors.white),),
                          ],
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 30,),
                  // const Divider(
                  //   color: Colors.white,
                  // ),
                  Center(
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 200,
                          width: 200,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset("assets/images/ali.jpeg"),
                          ),
                        ),
                        const SizedBox(height: 5,),
                        const Text(
                          "Muhammad Ali kulachi",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,color: Colors.white
                          ),
                        ),
                        const SizedBox(height: 5,),
                        Text("Senior Advocate High Court",style: TextStyle(fontSize: 18,
                            fontWeight: FontWeight.bold,color: Colors.white),)
                      ],
                    ),
                  ),
                  const SizedBox(height: 30,),
                  Center(
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 200,
                          width: 200,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset("assets/images/zeeshan.jpg"),
                          ),
                        ),
                        const SizedBox(height: 5,),
                        const Text(
                          "Zeeshan Azeem Khitran",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,color: Colors.white
                          ),
                        ),
                        const SizedBox(height: 5,),
                        Text("Advisor & Taxation Department",style: TextStyle(fontSize: 18,
                            fontWeight: FontWeight.bold,color: Colors.white),)
                      ],
                    ),
                  ),
                  const SizedBox(height: 30,),
                  Center(
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 200,
                          width: 200,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset("assets/images/tahzeeb.jpg"),
                          ),
                        ),
                        const SizedBox(height: 5,),
                        const Text(
                          "Tahzeeb Naveed",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,color: Colors.white
                          ),
                        ),
                        const SizedBox(height: 5,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text("Taxation & IT Department",style: TextStyle(fontSize: 18,
                                fontWeight: FontWeight.bold,color: Colors.white),),
                          ],
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 30,),
                  Center(
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 200,
                          width: 200,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset("assets/images/Arslan.jpeg"),
                          ),
                        ),
                        const SizedBox(height: 5,),
                        const Text(
                          "Arslan Shabir",
                          style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,color: Colors.white
                          ),
                        ),
                        const SizedBox(height: 5,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text("Advisor & Taxation Department",style: TextStyle(fontSize: 18,
                                fontWeight: FontWeight.bold,color: Colors.white),),
                          ],
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 20,),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}