import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lawer_app/auth/log_in.dart';
import 'package:lawer_app/screens/about_us.dart';
import 'package:lawer_app/screens/category_pg.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'global_var.dart';


class homescreen extends StatefulWidget {
  @override
  State<homescreen> createState() => _homescreenState();

}

class _homescreenState extends State<homescreen> {

  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
    Firebase.initializeApp().whenComplete(() {
    });
  }
  String name="";
  String email="";
  void getData()async{
      User? user = await FirebaseAuth.instance.currentUser;
      var vari = await FirebaseFirestore.instance.collection(
          "UserSigningDetails").doc(user!.uid).get();
      setState(() {
        name = vari.data()!['displayName'];
        email = vari.data()!['email'];
        // print(vari.data());
      });
  }
  final FirebaseAuth firebase = FirebaseAuth.instance;

  @override

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.grey[900],
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.grey[700],
          child: ListView(
            children: [
              SizedBox(
                height: 270,
                child: UserAccountsDrawerHeader(decoration: BoxDecoration(color: Colors.grey[800],
                  image: DecorationImage(
                    image: AssetImage("assets/images/law.png"),fit: BoxFit.fill,
                  ),
                ),
                    accountName: Text("Name: $name",
                      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                    ), accountEmail: Text("Email: $email",
                    maxLines: 5,
                    style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                ),
              ),
              ListTile(
                leading: Icon(
                  Icons.home,color: Colors.white,
                ),
                title: Text('Home',style: TextStyle(color: Colors.white,fontSize: 20),),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => homescreen(),
                  ),
                  );
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.privacy_tip_outlined,color: Colors.white,
                ),
                title: const Text('Privacy Polices',style: TextStyle(color: Colors.white,fontSize: 20),),
                onTap: () {
                  showprivacyAlert();
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.info,color: Colors.white,
                ),
                title: const Text('About App',style: TextStyle(color: Colors.white,fontSize: 20),),
                onTap: () {
                  showDataAlert();
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.logout,color: Colors.white,
                ),
                title: const Text('LogOut',style: TextStyle(color: Colors.white,fontSize: 20),),
                onTap: () async {
                  SharedPreferences prefs = await SharedPreferences.getInstance();
                  prefs.remove('email');
                  signOut(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.exit_to_app,color: Colors.white,
                ),
                title: const Text('Exit App',style: TextStyle(color: Colors.white,fontSize: 20),),
                onTap: ()  {
                  SystemNavigator.pop();
                },
              ),
            ],
          ),
        ),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: Row(
          children: [
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          Text("Your Law Services",style: TextStyle(
                            fontSize: 35,color: Colors.white,fontStyle: FontStyle.italic
                          ),),
                          Text("(Smart Support)",style: TextStyle(
                              fontSize: 20,color: Colors.white,fontStyle: FontStyle.italic
                          ),),
                        ],
                      ),
                    ),
                    SizedBox(height: 100,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        MaterialButton(
                          padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
                          shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                              side: BorderSide(color: Colors.black,width: 3.0)
                          ),
                          minWidth: 170,
                          height: 170,
                          child: Column(
                            children: [
                              Icon(Icons.gavel_rounded,color: Colors.yellow[700],size: 100,),
                              Text(category1,
                                style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.yellow[700]),),
                            ],
                          ),
                          onPressed: () {
                            Globals.catg1 = category1;
                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => law_pg(),
                            ),
                            );
                          },
                        ),
                        SizedBox(width: 20,),
                        MaterialButton(
                          padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
                          shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                              side: BorderSide(color: Colors.black,width: 3.0)
                          ),
                          minWidth: 170,
                          height: 170,
                          child: Column(
                            children: [
                              Icon(Icons.account_balance_outlined,color: Colors.yellow[700],size: 100,),
                              Text(category2,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.yellow[700]),),
                            ],
                          ),
                          onPressed: () {
                            Globals.catg1 = category2;
                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => tax_pg(),
                            ),
                            );
                          },
                        ),
                      ],
                    ),
                    SizedBox(height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        MaterialButton(
                          padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
                          shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                              side: BorderSide(color: Colors.black,width: 3.0)
                          ),
                          minWidth: 170,
                          height: 170,
                          child: Column(
                            children: [
                              Icon(Icons.airplay_outlined,color: Colors.yellow[700],size: 100,),
                              Text(category3,
                                style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.yellow[700]),),
                            ],
                          ),
                          onPressed: () {
                            Globals.catg1 = category3;
                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => cyber_pg(),
                            ),
                            );
                          },
                        ),
                        SizedBox(width: 20,),
                        MaterialButton(
                          padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
                          shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                            side: BorderSide(color: Colors.black,width: 3.0)
                          ),

                          minWidth: 170,
                          height: 170,
                          child: Column(
                            children: [
                              Icon(Icons.person_outline_rounded,color: Colors.yellow[700],size: 100,),
                              SizedBox(height: 5,),
                              Text("About Us",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.yellow[700]),),
                              SizedBox(height: 20,),
                            ],
                          ),
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => AboutUs(),
                            ),
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
          ],
        ),
      ),
    );
  }

  showDataAlert() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  20.0,
                ),
              ),
            ),
            contentPadding: EdgeInsets.only(
              top: 10.0,
            ),
            title: Text(
              "Law App",
              style: TextStyle(fontSize: 24.0),
            ),
            content: Container(
              height: 300,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('Note:',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text("Support Service is an application to find out about rules and laws of Pakistan"
                        "You can get the various information on laws like Law & Order, Excise & Taxation, Cyber Crime etc."
                        "After knowing about these laws you can complaint on our given number which is provided in complaint"
                        "section to consult with experts.You can text your categories, name and complaint on our provided whatsapp number.",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      height: 60,
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.black,
                          // fixedSize: Size(250, 50),
                        ),
                        child: Text(
                          "Close",
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }
  showprivacyAlert() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  20.0,
                ),
              ),
            ),
            contentPadding: EdgeInsets.only(
              top: 10.0,
            ),
            title: Text(
              "Law App",
              style: TextStyle(fontSize: 24.0),
            ),
            content: Container(
              height: 300,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('Note:',style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text("In addition to law enacted at the federal level, states also have privacy and data security laws.Most states have so-called “mini-FTC Acts” under which they have authority similar to that of the FTC to take enforcement actions in response to unfair or deceptive trade practices.  This could include tracking consumers without proper notice or when a promise has been made not to track consumer behavior. A number of state attorneys general have been vigilant in enforcing against entities collecting personal information from consumers.Some states have specific privacy laws covering particular kinds of data and data collection, such as California. It would appear that many of these specific laws apply to Apps and the companies that operate them.Forty-six states also have data security breach notification laws that require entities holding personal data to provide notices in the event of breaches of the security of that data, and those laws apply regardless of how the data may have been collected, meaning that data that is collected by Apps that is subject to a security breach will trigger notification obligations.",
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      height: 60,
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.black,
                          // fixedSize: Size(250, 50),
                        ),
                        child: Text(
                          "Close",
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }
  Future<void>signOut(BuildContext context) async {
await firebase .signOut().then((_) {
  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => login()));
}
);
  }
}