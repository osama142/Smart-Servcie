import 'dart:ui';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:lawer_app/auth/forget_pass.dart';
import 'package:lawer_app/auth/sign_up.dart';
import 'package:lawer_app/screens/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);
  @override
  _loginState createState() => _loginState();
}
class _loginState extends State<login> {

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? validateEmail(value)  {
    RegExp regExp = RegExp(
        r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?)*$");
    if(value.isEmpty) {
      return "Email required";
    }
    else if(!regExp.hasMatch(value)) {
      return "Enter a valid Email Address";
    }
    else {
      return null;
    }
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Firebase.initializeApp().whenComplete(() {
    });
  }
  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
        body: Container(
          color: Colors.grey[800],
          child: Container(
          child: ProgressHUD(
            child: Builder(
                builder: (context) {
                  final progress = ProgressHUD.of(context);
                  return Form(
                    autovalidateMode: AutovalidateMode.always, key: _formKey,
                    child: SingleChildScrollView(
                      child: Row(
                        children: [
                      SizedBox(width: MediaQuery.of(context).size.width*0.05,),
                          Container(
                            width: MediaQuery.of(context).size.width*0.9,
                            child: Column(
                              children: [
                                Container(
                                  height: 320,
                                  child: Image(image: AssetImage("assets/images/law.png"),),
                                ),
                                Container(
                                  margin: const EdgeInsets.all(10),
                                  //height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  child: TextFormField(
                                    style: TextStyle(color: Colors.white),
                                    controller: emailController,
                                    validator: validateEmail,
                                    keyboardType: TextInputType.emailAddress,
                                    decoration:  InputDecoration(
                                      border: OutlineInputBorder(),
                                      labelText: "Email",
                                      labelStyle: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10.0,
                                ),
                                Container(
                                  // color: Colors.grey[100],
                                  margin: const EdgeInsets.all(10),
                                  //padding: EdgeInsets.all(10),
                                  width: MediaQuery.of(context).size.width,
                                  child: TextFormField(
                                    style: TextStyle(color: Colors.white),
                                    validator: (input) {
                                      if(input!.length<6) {
                                        return "Password required";
                                      }
                                      else {
                                        return null;
                                      }
                                    },
                                    controller: passwordController,
                                    obscureText: true,
                                    decoration: const InputDecoration(
                                      border: OutlineInputBorder(),
                                      labelText: "Password",
                                      labelStyle: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topRight,
                                  child: InkWell(
                                    onTap: () {
                                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => ForgetPass(),
                                      ),
                                      );
                                    },
                                    child: const Text(
                                      'Update your password?',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 20.0,
                                ),
                                SizedBox(
                                  height: 50,
                                  width: 370.0,
                                  child: MaterialButton(
                                    shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.only(
                                          bottomRight: Radius.circular(13.0),
                                          topRight: Radius.circular(13.0),
                                          bottomLeft: Radius.circular(13.0),
                                          topLeft: Radius.circular(13.0)),
                                    ),
                                    color: Colors.yellow[800],
                                    onPressed: () async {
                                      if(_formKey.currentState!.validate())
                                      {
                                        progress!.showWithText("Logging In...");
                                        try {
                                          await FirebaseAuth.instance.signInWithEmailAndPassword(
                                            email: emailController.text,
                                            password: passwordController.text,
                                          ).then((value) async {
                                            SharedPreferences prefs = await SharedPreferences.getInstance();
                                            await prefs.setString('uid', value.user!.uid);
                                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => homescreen(),
                                            ),
                                            );
                                          });
                                        } on FirebaseAuthException catch (e) {
                                          if (e.code == 'user-not-found') {
                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("No user found for that email."),));
                                          }
                                          else {
                                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Incorrect Password"),));
                                          }
                                        }
                                        progress.dismiss();
                                      }
                                    },
                                    child: const SizedBox(
                                      width: 200,
                                      height: 50,
                                      child: Center(
                                        child: Text(
                                          'Login',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 20.0,
                                ),
                                const Text("Don't have an account?",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20.0,
                                  ),
                                ),
                                const SizedBox(
                                  height: 20.0,
                                ),
                                Container(
                                  width: 150,
                                  height: 40,
                                  decoration:  BoxDecoration(
                                    color: Colors.yellow[800],
                                    borderRadius: BorderRadius.only(
                                        bottomRight: Radius.circular(9.0),
                                        topRight: Radius.circular(9.0),
                                        bottomLeft: Radius.circular(9.0),
                                        topLeft: Radius.circular(9.0)),
                                  ),
                                  alignment: Alignment.center,
                                  child: InkWell(
                                    onTap: () {
                                      Navigator.of(context).push(
                                          MaterialPageRoute(builder: (context) => signup_()),
                                      );
                                    },
                                    child: const Text("Sign Up",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 20.0,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: MediaQuery.of(context).size.width*0.05,),
                        ],
                      ),
                    ),
                  );
                }
            ),
          ),
          ),


        ),
      );
  }

  void signIn () {
    final formState = _formKey.currentState;
    if(formState!.validate())
    {

    }
  }
}
