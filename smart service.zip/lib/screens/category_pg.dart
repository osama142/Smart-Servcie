import 'package:flutter/material.dart';
import 'package:lawer_app/screens/detail_pg.dart';

import 'global_var.dart';

class law_pg extends StatefulWidget {
  @override
  State<law_pg> createState() => _law_pgState();
}

class _law_pgState extends State<law_pg> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.grey[900],
        leading: IconButton
          (icon: Icon(Icons.arrow_back), onPressed: () { Navigator.pop(context); },),
        title: Text("Please Select your Category...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: Row(
          children: [
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Column(
                      children: [
                        Text("Your Law Services",style: TextStyle(
                            fontSize: 35,color: Colors.white,fontStyle: FontStyle.italic
                        ),),
                        Text("(Smart Support)",style: TextStyle(
                            fontSize: 20,color: Colors.white,fontStyle: FontStyle.italic
                        ),),
                      ],
                    ),
                    SizedBox(height: 50,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category4,
                                    style: TextStyle(color: Colors.yellow[700],
                                        fontWeight: FontWeight.bold,fontSize: 25),
                                  ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,
                              size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                              Globals.catg2 = category4;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => criminal(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category5,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 25,),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category5;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => civil(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category6,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category6;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => family(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category7,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category7;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => estate(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category8,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category8;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => employm(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
          ],
        ),
      ),
    );
  }
}


class tax_pg extends StatefulWidget {
  @override
  State<tax_pg> createState() => _tax_pgState();
}

class _tax_pgState extends State<tax_pg> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.grey[900],
        leading: IconButton
          (icon: Icon(Icons.arrow_back), onPressed: () { Navigator.pop(context); },),
        title: Text("Please Select your Category...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: Row(
          children: [
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Column(
                      children: [
                        Text("Your Law Services",style: TextStyle(
                            fontSize: 35,color: Colors.white,fontStyle: FontStyle.italic
                        ),),
                        Text("(Smart Support)",style: TextStyle(
                            fontSize: 20,color: Colors.white,fontStyle: FontStyle.italic
                        ),),
                      ],
                    ),
                    SizedBox(height: 50,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category9,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 25),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,
                              size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category9;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => ntn(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category10,
                              style: TextStyle(color: Colors.yellow[700],
                                fontWeight: FontWeight.bold,fontSize: 25,),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category10;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => corporate(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category11,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 25),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category11;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => audit(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category12,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category12;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => impooort(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category13,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category13;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => logo(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
          ],
        ),
      ),
    );
  }
}



class cyber_pg extends StatefulWidget {
  @override
  State<cyber_pg> createState() => _cyber_pgState();
}

class _cyber_pgState extends State<cyber_pg> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.grey[900],
        leading: IconButton
          (icon: Icon(Icons.arrow_back), onPressed: () { Navigator.pop(context); },),
        title: Text("Please Select your Category...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: Row(
          children: [
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Column(
                      children: [
                        Text("Your Law Services",style: TextStyle(
                            fontSize: 35,color: Colors.white,fontStyle: FontStyle.italic
                        ),),
                        Text("(Smart Support)",style: TextStyle(
                            fontSize: 20,color: Colors.white,fontStyle: FontStyle.italic
                        ),),
                      ],
                    ),
                    SizedBox(height: 50,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category14,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 25),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,
                              size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category14;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => hacking(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category15,
                              style: TextStyle(color: Colors.yellow[700],
                                fontWeight: FontWeight.bold,fontSize: 25,),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category15;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => face(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category16,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 25),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category16;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => defam(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category17,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 25),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category17;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => bank(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category18,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 25),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category18;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => crypto(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category19,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category19;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => fraud(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category20,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category20;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => porn(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(category21,
                              style: TextStyle(color: Colors.yellow[700],
                                  fontWeight: FontWeight.bold,fontSize: 20),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(icon: Icon(Icons.arrow_circle_right_outlined,size: 35,color: Colors.yellow[700],),
                              onPressed: () {
                                Globals.catg2 = category21;
                                Navigator.of(context).push(MaterialPageRoute(builder: (context) => harass(),
                                ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(width: MediaQuery.of(context).size.width*0.05,),
          ],
        ),
      ),
    );
  }
}