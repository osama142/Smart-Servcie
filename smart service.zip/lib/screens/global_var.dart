library globals;
//Category 1
var category1 = "Law Consultancy";
var category2 = "Taxation Law & Services";
var category3 = "Electronic & CyberCrime";
//Category 2
var category4 = "Criminal Law";
var category5 = "Civil Law";
var category6 = "Families Law";
var category7 = "Real Estate & Property Law";
var category8 = "Employment/Service Law";

var category9 = "NTN & File your income Returns";
var category10 = "Corporate Tax";
var category11 = "Audit";
var category12 = "Import, Export License";
var category13 = "Logo & TradeMark Registration";

var category14 = "Hacking";
var category15 = "Facebook Abuse";
var category16 = "Online Defamation";
var category17 = "Online Banking Frauds";
var category18 = "Crypto Currency & Block Chain";
var category19 = "MLM Frauds";
var category20 = "Pornography Laws";
var category21 = "Harassment";

class Globals{
  static var catg1;
  static var catg2;
}





