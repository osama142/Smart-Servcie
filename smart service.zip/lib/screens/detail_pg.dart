import 'package:flutter/material.dart' ;
import 'package:lawer_app/screens/m_msg.dart';

class criminal extends StatefulWidget {
  @override
  State<criminal> createState() => _criminalState();
}

class _criminalState extends State<criminal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
            Navigator.pop(context);
        },
          icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Criminal Law",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Criminal law, as distinguished from civil law, is a system of laws concerned with punishment of individuals who commit crimes. Thus, where in a civil case two individuals dispute their rights, a criminal prosecution involves the government deciding whether to punish an individual for either an act or an omission.",
                      style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class civil extends StatefulWidget {
  @override
  State<civil> createState() => _civilState();
}

class _civilState extends State<civil> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Civil Law",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Civil law is a legal system originating and intellectualized within the framework of common law, the key feature of which is that its core principles are codified into a referable system which serves as the prime source of law. Civil law, or civilian law, also known as private law, regulates disputes between private persons or corporate entities. It deals with issues such as personal injury, contracts, property, inheritance and family law.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class family extends StatefulWidget {
  @override
  State<family> createState() => _familyState();
}

class _familyState extends State<family> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Family Laws",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Family law, also known as matrimonial law or the law of native relations, is an area of the law that deals with family affairs and domestic relations, such as adoption, divorce, child custody and support etcetera."
                        ,
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class estate extends StatefulWidget {
  @override
  State<estate> createState() => _estateState();
}

class _estateState extends State<estate> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Real Estate & Property Law",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Property law is the area of law that governs the various form of ownership in real property (land as distinct from personal or movable possessions) and in personal property, within the common law legal system. In the civil law system, there is a division between movable and immovable property. Movable property roughly corresponds to personal property, while immovable property corresponds to real estate or real property, and the associated rights and obligations thereon.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class employm extends StatefulWidget {
  @override
  State<employm> createState() => _employmState();
}

class _employmState extends State<employm> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Employment & Service Law",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Employment law regulates the relationship between employers and employees. It governs what employers can expect from employees, what employers can ask employees to do, and employees' rights at work.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class ntn extends StatefulWidget {
  @override
  State<ntn> createState() => _ntnState();
}

class _ntnState extends State<ntn> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("NTN & File your income Returns",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Salaried person would need to complete the Declaration form 114(I) in order to successfully submit their Income Tax Return. Persons who are deriving income only from salary and other sources, where salary is more than 50% of Income can avail this form."
                        ,
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}



class corporate extends StatefulWidget {
  @override
  State<corporate> createState() => _corporateState();
}

class _corporateState extends State<corporate> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Corporate Tax",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("A resident company is taxed on its worldwide income. Non-resident companies operating in Pakistan through a branch are taxed on their Pakistan-source income attributable to the branch at rates applicable to a company.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}



class audit extends StatefulWidget {
  @override
  State<audit> createState() => _auditState();
}

class _auditState extends State<audit> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Audit",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("The term audit usually refers to a financial statement audit. A financial audit is an objective examination and evaluation of the financial statements of an organization to make sure that the financial records are a fair and accurate representation of the transactions they claim to represent. The audit can be conducted internally by employees of the organization or externally by an outside Certified Public Accountant (CPA) firm.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class impooort extends StatefulWidget {
  @override
  State<impooort> createState() => _impooortState();
}

class _impooortState extends State<impooort> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Import, Export License",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("To get an import license in Pakistan, you need to send the proof of the fulfillment of these requirements to the Federal Board of Revenue (FBR). Emerhub will assist you with meeting these requirements for the import license and make the necessary arrangements on your behalf.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class logo extends StatefulWidget {
  @override
  State<logo> createState() => _logoState();
}

class _logoState extends State<logo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Logo & Trademark Registration",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("A trademark can be defined as the unique identity that makes your company, product, or service stand out from the rest. A registered trademark is your business’s intellectual property/ intangible asset. It protects the investment made into creating trust and loyalty among your customers."
                        "The registration provides the right to sue against others who try to copy your trademark and prevents others from using a similar trademark to the one registered by you.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}

class hacking extends StatefulWidget {
  @override
  State<hacking> createState() => _hackingState();
}

class _hackingState extends State<hacking> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Hacking",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("It provides a comprehensive framework for various types of cybercrimes in Pakistan which, in sync with the Cyber Crime Bill 2007, deals with internet crimes in the country, such as illegal access to data (through hacking), Denial of Service Attacks (DOS Attack), electronic forgery and electronic fraud.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}


class face extends StatefulWidget {
  @override
  State<face> createState() => _faceState();
}

class _faceState extends State<face> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Facebook Abuse",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("The Prevention of Electronic Crimes Act, 2016, guarantees strict punishments for online bullies. For instance, spreading wrong information about someone online can lead to up to three years in prison along with a fine of one million rupees or both.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}

class defam extends StatefulWidget {
  @override
  State<defam> createState() => _defamState();
}

class _defamState extends State<defam> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Online Defamation",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Defamation law terms defamation a statement that injures a third party's reputation. The scope of defamation includes both libel (published statement) and slander (verbal statement). Defamation is to diminish the esteem, respect, goodwill or confidence in which the plaintiff is held, or to excite adverse, derogatory or unpleasant feelings or opinions against the affected person.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}

class bank extends StatefulWidget {
  @override
  State<bank> createState() => _bankState();
}

class _bankState extends State<bank> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Online Baking Frauds",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("The general public is hereby warned that the name of the State Bank and its official logo and the name of the Banking"
                          "Laws Review Commission are being misused for fraudulent purposes. The most common method involves victims being"
                          "notified of monies to be paid to them, by way of an inheritance, by the State Bank’s Overseas Branch. To gain access to"
                          "these funds, victims are asked to provide personal information e.g bank account number or mobile telephone number etc.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}

class crypto extends StatefulWidget {
  @override
  State<crypto> createState() => _cryptoState();
}

class _cryptoState extends State<crypto> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Crypto Currency & Block Chain",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("In April 2018, the State Bank of Pakistan (SBP) declared that cryptocurrencies are not legal and not recognised, issued or guaranteed by the government. Earlier this year, the Sindh High Court, federal government and the State Bank of Pakistan recommended a complete ban on cryptos.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}

class fraud extends StatefulWidget {
  @override
  State<fraud> createState() => _fraudState();
}

class _fraudState extends State<fraud> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("MLM Fraud",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Multi-level marketing is a lawful and legitimate business method that uses a network of independent representatives to sell consumer products.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}

class porn extends StatefulWidget {
  @override
  State<porn> createState() => _pornState();
}

class _pornState extends State<porn> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Pornography Laws",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Pornography in Pakistan, like in many countries with a religious majority, is a touchy subject. Like its neighbors, Pakistan adopted a conservative stance on pornography that seeks to preserve what it sees as the religious and cultural integrity of its youth.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}

class harass extends StatefulWidget {
  @override
  State<harass> createState() => _harassState();
}

class _harassState extends State<harass> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (onPressed: () {
          Navigator.pop(context);
        },
            icon:Icon(Icons.arrow_back)),
        backgroundColor: Colors.grey[900],
        title: Text("Details & Ask Now...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Row(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
              Container(
                width: MediaQuery.of(context).size.width*0.9,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Text("Harassment",style: TextStyle(
                        fontWeight: FontWeight.bold,fontSize: 40,color: Colors.white,fontStyle: FontStyle.italic),),
                    SizedBox(height: 20,),
                    Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(
                          color: Colors.black,
                          width: 3.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text("Harassment covers a wide range of behaviors of offensive nature. It is commonly understood as behavior that demeans, humiliates or embarrasses a person, and it is characteristically identified by its unlikelihood in terms of social and moral reasonableness. In the legal sense, these are behaviors that appear to be disturbing, upsetting or threatening. They evolve from discriminatory grounds, and have an effect of nullifying a person's rights or impairing a person from benefiting from their rights. When these behaviors become repetitive, it is defined as bullying. The continuity or repetitiveness and the aspect of distressing, alarming or threatening may distinguish.",
                        style: TextStyle(fontSize: 25,color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 50,),
                    MaterialButton(
                      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                          side: BorderSide(color: Colors.black,width: 3.0)
                      ),
                      color: Colors.yellow[800],
                      minWidth: 361,
                      height: 60,
                      child: Text("Ask Now/Complaint",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => m_msg(),
                        ),
                        );
                      },
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width*0.05,),
            ],
          ),
        ),
      ),
    );
  }
}



