import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_progress_hud/flutter_progress_hud.dart';
import 'package:lawer_app/auth/log_in.dart';
import 'package:lawer_app/screens/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';


class signup_ extends StatefulWidget {
  const signup_({Key? key}) : super(key: key);

  //const signup({ Key? key }) : super(key: key);

  @override
  _signup_State createState() => _signup_State();
}

class _signup_State extends State<signup_> {

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  _getSharedPref() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('email', _emailController.text);
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Firebase.initializeApp().whenComplete(() {
    });
  }
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? validateEmail(value)  {
    RegExp regExp = RegExp(
        r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?)*$");
    if(value.isEmpty) {
      return "Email required";
    }
    if(!regExp.hasMatch(value)) {
      return "Enter a valid Email Address";
    } else {
      return null;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.grey[800],
        child: ProgressHUD(
          child: Builder(
              builder: (context) {
                final progress = ProgressHUD.of(context);
                return Form(
                  autovalidateMode: AutovalidateMode.always, key: _formKey,
                  child: SingleChildScrollView(
                    child: Row(
                      children: [
                        SizedBox(width: MediaQuery.of(context).size.width*0.05,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width*0.9,
                          child: Column(
                            children: [
                              Container(
                                height: 320,
                                child: Image(image: AssetImage("assets/images/law.png"),),
                              ),
                              nm(0,"Full Name",),
                              const SizedBox(
                                height: 10.0,
                              ),
                              mail(1,"Email",_emailController),
                              const SizedBox(
                                height: 10.0,
                              ),
                              Container(
                                margin: const EdgeInsets.all(10),
                                alignment: Alignment.topLeft,
                              ),
                              label(2,"Password",_passwordController),
                              const SizedBox(
                                height: 15.0,
                              ),
                              Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                  ],
                                ),
                              ),
                              //
                              SizedBox(
                                height: 50,
                                width: 370,
                                child: MaterialButton(
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(
                                        bottomRight: Radius.circular(13.0),
                                        topRight: Radius.circular(13.0),
                                        bottomLeft: Radius.circular(13.0),
                                        topLeft: Radius.circular(13.0)),
                                  ),
                                  color: Colors.yellow[800],
                                  onPressed: () async {
                                    // _getSharedPref();
                                    if(_formKey.currentState!.validate())
                                    { progress!.showWithText("Signing Up...");
                                    try {
                                      await FirebaseAuth.instance.createUserWithEmailAndPassword(
                                        email: _emailController.text,
                                        password: _passwordController.text,
                                      ).then((value) {
                                        print("USER CREATED ${value.user!.email}");
                                        createRecord(value.user);
                                        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => login(),
                                        ),
                                        );
                                      });
                                    } on FirebaseAuthException catch (e) {
                                      if (e.code == 'email-already-in-use') {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(const SnackBar(content: Text("Account already exists for that email."),));
                                      }
                                    } catch (e) {
                                      print(e);
                                    }
                                    progress.dismiss();
                                    }
                                  },

                                  child:  Center(
                                    child: Text(
                                      'SignUp',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 20.0,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width: MediaQuery.of(context).size.width*0.05,),
                      ],
                    ),
                  ),
                );
              }
          ),
        ),
      ),
    );
  }
  Widget label (int index, String s, TextEditingController controller) {
    return Container(
      margin: const EdgeInsets.all(10),
      width: MediaQuery.of(context).size.width,
      child: TextFormField(
        style: TextStyle(color: Colors.white),
        controller: controller,
        validator: (input) {
          if(input!.length<6) {
            return 'Password must be at least 6 characters';
          }
          if(input.isEmpty) {
            return "Empty";
          }
          return null;
        },
        obscureText: true,
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          labelText: s,
          labelStyle: TextStyle(color: Colors.white),
          //  hintText: "Description of the new classroom",
        ),
      ),
    );
  }
  Widget mail (int i, String e, TextEditingController emailController) {
    return Container(
      margin: const EdgeInsets.all(10),
      width: MediaQuery.of(context).size.width,
      child: TextFormField(
        style: TextStyle(color: Colors.white),
        controller: emailController,
        validator: validateEmail,
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          labelText: e,
          labelStyle: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
  Widget nm (int b, String n,) {
    return Container(
      margin: const EdgeInsets.all(10),
      width: MediaQuery.of(context).size.width,
      child: TextFormField(
        textCapitalization: TextCapitalization.words,
        style: TextStyle(color: Colors.white),
        controller: _nameController,
        validator: (input) {
          if(input!.isEmpty) {
            return "Name required";
          }
          else {
            return null;
          }
        },
        decoration:  InputDecoration(
          border: OutlineInputBorder(),
          labelText: n,
          labelStyle: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
  void createRecord(User? user) async {
    try {
      await FirebaseFirestore.instance.collection("UserSigningDetails").doc(
          user!.uid)
          .set({
        'displayName': _nameController.text,
        'email': _emailController.text,
        'password': _passwordController.text,
      }).then((value) => _getSharedPref());
    }
    catch (e) {

    }
  }
}
