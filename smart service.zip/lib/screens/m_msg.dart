import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart' ;
import 'package:lawer_app/screens/global_var.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';

import 'global_var.dart';

class m_msg extends StatefulWidget {
  const m_msg({Key? key}) : super(key: key);

  @override
  _m_msgState createState() => _m_msgState();
}

class _m_msgState extends State<m_msg> {
  final TextEditingController categ = TextEditingController(text: Globals.catg1.toString());
  final TextEditingController categ2 = TextEditingController(text: Globals.catg2);
  var msg = "";
  var nam = "";
  var code = "+92";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton
          (icon: Icon(Icons.arrow_back), onPressed: () { Navigator.pop(context); },),
        backgroundColor: Colors.grey[900],
        title:  Text("Send Message to WhatsApp or SMS...",style: TextStyle(
          fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white,
        ),),
      ),
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          image:  DecorationImage(
            fit: BoxFit.cover,
            colorFilter:
            ColorFilter.mode(Colors.black.withOpacity(0.3),
                BlendMode.dstATop),
            image: AssetImage(
              'assets/images/home_back.jpg',
            ),
          ),
        ),
        child: Center(
          child: Container(
            padding: EdgeInsets.only(left: 40, right: 40),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  MaterialButton(
                    onPressed: () {},
                    color: Colors.yellow[700],
                    shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                        side: BorderSide(color: Colors.black,width: 2.0)
                    ),
                    child: CountryCodePicker(
                      onChanged: (val) {
                        code = val.toString();
                      },
                      initialSelection: 'Pakistan',
                      favorite: ['+92', 'Pakistan'],
                      showCountryOnly: false,
                      showOnlyCountryWhenClosed: false,
                      alignLeft: false,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color: Colors.black,
                        width: 3.0,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text("+92 3448490020",
                            style: TextStyle(color: Colors.yellow[700],
                                fontWeight: FontWeight.bold,fontSize: 25),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextField(
                    readOnly: true,
                    onTap: () {
                    },
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(23),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 3.0,
                        ),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    controller: categ,
                    style: TextStyle(color: Colors.yellow[700],
                        fontWeight: FontWeight.bold,fontSize: 20),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextField(
                    readOnly: true,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(23),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 3.0,
                        ),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    controller: categ2,
                    style: TextStyle(color: Colors.yellow[700],
                        fontWeight: FontWeight.bold,fontSize: 20),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextField(
                      textCapitalization: TextCapitalization.words,
                    onChanged: (value) {
                      nam = value;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(23),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Colors.black,
                            width: 3.0,
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Name",labelStyle: TextStyle(color: Colors.yellow[700])),
                    style: TextStyle(color: Colors.yellow[700],
                        fontWeight: FontWeight.bold,fontSize: 25),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextField(
                    textCapitalization: TextCapitalization.sentences,
                    onChanged: (value) {
                      msg = value;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(23),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Colors.black,
                            width: 3.0,
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        labelText: "Complaint Details",labelStyle: TextStyle(color: Colors.yellow[700])),
                    style: TextStyle(color: Colors.yellow[700],
                        fontWeight: FontWeight.bold,fontSize: 25),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  MaterialButton(
                    shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(15.0),
                        side: BorderSide(color: Colors.black,width: 3.0)
                    ),
                    color: Colors.yellow[800],
                    minWidth: 361,
                    height: 60,
                    child: Text("Send via WhatsApp",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                    onPressed: () async {
                      final link = WhatsAppUnilink(
                                    phoneNumber: '+92 3448490020',
                                    text: "Category 1: ${categ.text}\nCategory 2: ${categ2.text}\n"
                                        "Name: $nam\nComplaint: $msg",
                                  );
                                  if(await launch('$link')) {
                                    await launch('$link');
                                  }
                                  else {
                                    throw "WhatsApp Not Installed $link";
                                  }
                    },
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

}